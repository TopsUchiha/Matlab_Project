function sequence = build_sequence(start_val, seq_len)
    
    % Start the list with your first number
    sequence = start_val;
    
    % Loop to add the rest of the numbers one by one
    for i = 2:seq_len
        % Get the last number we made
        last_number = sequence(end);
        
        % Rule: If the last number is -1, do special math, otherwise do 2x + 1
        if last_number == -1
            next_number = (-1 * 2) + 1;
        else
            next_number = (last_number * 2) + 1;
        end
        
        % Glue the new number onto the end of our list
        sequence = [sequence, next_number];
    end
end