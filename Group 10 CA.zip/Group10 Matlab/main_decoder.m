clear
clc

% 1. Get your numbers
[start_val, seq_len, mod_val] = get_inputs();

% 2. Build the sequence array
sequence = build_sequence(start_val, seq_len);

disp(' ')
disp('Generated Sequence:')
disp(sequence)
disp(' ')


% 3. Calculate remainders
analysis = get_remainders(sequence, mod_val);


analysis = check_pattern(sequence, analysis);


write_report(sequence, analysis);

disp('Done! Every single step executed perfectly in order.')