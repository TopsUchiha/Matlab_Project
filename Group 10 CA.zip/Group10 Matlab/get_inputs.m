function [start_val, seq_len, mod_val] = get_inputs()
    
    start_val = input('Enter the starting number: ');
    
    seq_len = input('Enter the sequence length: ');
    while seq_len < 1
        disp('Error: Sequence length must be 1 or greater.')
        seq_len = input('Enter the sequence length: ');
    end
    
    mod_val = input('Enter the modulo divisor: ');
    while mod_val == 0
        disp('Error: Modulo divisor cannot be 0.')
        mod_val = input('Enter the modulo divisor: ');
    end
end