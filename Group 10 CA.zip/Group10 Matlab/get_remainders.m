function analysis = get_remainders(sequence, mod_val)
    calculated_rem = rem(sequence, mod_val);
    
    for k = 1:length(calculated_rem)
        if calculated_rem(k) < 0
            calculated_rem(k) = calculated_rem(k) + mod_val;
        end
    end
    
    analysis.remainders = calculated_rem;
    analysis.unique_rem = unique(calculated_rem);
end