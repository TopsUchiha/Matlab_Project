function write_report(sequence, analysis)
    fileID = fopen('analysis_report.txt', 'w');
    
    fprintf(fileID, '--- MODULAR SEQUENCE DECODER REPORT ---\n\n');
    fprintf(fileID, 'Generated Sequence: %s\n', num2str(sequence));
    fprintf(fileID, 'Remainder Classes:  %s\n', num2str(analysis.remainders));
    fprintf(fileID, 'Unique Remainders:  %s\n', num2str(analysis.unique_rem));
    fprintf(fileID, 'Sum of All Terms:   %s\n\n', num2str(analysis.total_sum));
    
    if analysis.has_pattern == 1
        fprintf(fileID, 'Pattern Detection: A repeating pattern WAS found.\n\n');
    else
        fprintf(fileID, 'Pattern Detection: No repeating pattern was detected.\n\n');
    end
    
    fprintf(fileID, '--- INDIVIDUAL TERM PROPERTIES ---\n');
    
    for i = 1:length(sequence)
        current_number = sequence(i);
        
        % Print the term number and its value first
        fprintf(fileID, 'Term %d (%d) is: ', i, current_number);
        
        % 1. Simple Odd or Even check
        if rem(current_number, 2) == 0
            fprintf(fileID, 'Even ');
        else
            fprintf(fileID, 'Odd ');
        end
        
        % 2. Simple Prime check
        if current_number > 1 && current_number < 1000
            if isprime(current_number)
                fprintf(fileID, 'and Prime');
            else
                % If it is not prime, find the factors and print them simply
                f = factor(current_number);
                fprintf(fileID, 'with Prime Factors: %s', num2str(f));
            end
        end
        
        % Move to the next line for the next number
        fprintf(fileID, '\n');
    end
    
    fclose(fileID);
end