function analysis = check_pattern(sequence, analysis)
    
    analysis.has_pattern = 0;
    if length(analysis.remainders) >= 4
        if analysis.remainders(1) == analysis.remainders(3) && analysis.remainders(2) == analysis.remainders(4)
            analysis.has_pattern = 1;
        end
    end
    
    analysis.total_sum = sum(sequence);
end